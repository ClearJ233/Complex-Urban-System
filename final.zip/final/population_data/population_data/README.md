# Population Data

## Annual Estimates of the Resident Population for Metropolitan Statistical Areas
### cbsa-met-est2019-annres.xlsx: 2010 - 2019
### cbsa-met-est2023-pop.xlsx：2020 - 2023

## Annual Estimates of the Resident Population for Micropolitan Statistical Areas
### cbsa-mic-est2019-annres.xlsx: 2010 - 2019
### cbsa-mic-est2023-pop.xlsx: 2020 - 2023

## Annual Estimates of the Resident Population for States
### nst-est2019-01.xlsx: 2010 - 2019
### NST-EST2023-POP.xlsx: 2020 - 2023